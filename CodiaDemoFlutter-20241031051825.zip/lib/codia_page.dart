import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';

class CodiaPage extends StatefulWidget {
  CodiaPage({super.key});

  @override
  State<StatefulWidget> createState() => _CodiaPage();
}

class _CodiaPage extends State<CodiaPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: SizedBox(
        width: 4790,
        height: 2132,
        child: Stack(
          children: [
            Positioned(
              left: 2831,
              width: 430,
              top: 0,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 252,
                      child: Container(
                        width: 430,
                        height: 252,
                        decoration: BoxDecoration(
                          color: const Color(0x68ffbbbb),
                          border: Border.all(color: const Color(0xd2ffcc99), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I8831512871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image1_88316.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image2_88322.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79.25,
                      height: 22.5,
                      child: Image.asset('images/image3_88323.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image4_88326.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image5_88327.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 31,
                      width: 45,
                      top: 70,
                      height: 44,
                      child: Image.asset('images/image6_88339.png', width: 45, height: 44, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image7_88364.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image8_88367.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image9_88368.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 85,
                      width: 102,
                      top: 352,
                      height: 25,
                      child: Container(
                        width: 102,
                        height: 25,
                        decoration: BoxDecoration(
                          color: const Color(0xfff8f5f0),
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: const [BoxShadow(color: const Color(0x3f000000), offset: Offset(0, 4), blurRadius: 4),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 99,
                      top: 353,
                      child: Text(
                        'Individual',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff000000), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 248,
                      width: 103,
                      top: 353,
                      height: 25,
                      child: Container(
                        width: 103,
                        height: 25,
                        decoration: BoxDecoration(
                          color: const Color(0xfff8f5f0),
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: const [BoxShadow(color: const Color(0x3f000000), offset: Offset(0, 4), blurRadius: 4),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 257,
                      top: 353,
                      child: Text(
                        'Community',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff000000), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 31,
                      width: 374,
                      top: 126,
                      child: Image.asset('images/image10_277488.png', width: 374,),
                    ),
                    Positioned(
                      left: 19,
                      width: 392,
                      top: 392,
                      height: 445,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 6, top: 2, right: 6, bottom: 2),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    height: 264,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 0,
                                          width: 378,
                                          top: 0,
                                          height: 264,
                                          child: Container(
                                            width: 378,
                                            height: 264,
                                            decoration: BoxDecoration(
                                              color: const Color(0xffffffff),
                                              border: Border.all(color: const Color(0xfff3767c), width: 1),
                                              borderRadius: BorderRadius.circular(15),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          left: 34,
                                          width: 336,
                                          top: 28,
                                          child: Text(
                                            'Name: Sarah Suhari Items:  2 Rice bags  5 Cooking oil  Phone number: 018-49862746 Address: 18, Jalan Kebun, Seksyen 30,  40460 Shah Alam, Selangor, Malaysia Link to address: ',
                                            textAlign: TextAlign.left,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 302,
                                          width: 54,
                                          top: 234,
                                          height: 21,
                                          child: Container(
                                            width: 54,
                                            height: 21,
                                            decoration: BoxDecoration(
                                              color: const Color(0xff6e0b2a),
                                              border: Border.all(color: const Color(0xffa21441), width: 1),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  left: 0,
                                                  width: 54,
                                                  top: 0,
                                                  height: 21,
                                                  child: Text(
                                                    'Donate',
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                    maxLines: 9999,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 11),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    height: 264,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 0,
                                          width: 378,
                                          top: 0,
                                          height: 264,
                                          child: Container(
                                            width: 378,
                                            height: 264,
                                            decoration: BoxDecoration(
                                              color: const Color(0xffffffff),
                                              border: Border.all(color: const Color(0xfff3767c), width: 1),
                                              borderRadius: BorderRadius.circular(15),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          left: 34,
                                          width: 336,
                                          top: 27,
                                          child: Text(
                                            'Name: Emily Aster Items:  5 Cereal boxes  6 Milk cartons  5 Baby formula  Phone number: 012-3456789 Address: 12, Jalan Ampang, Kampung Baru,  50450 Kuala Lumpur, Malaysia Link to address: ',
                                            textAlign: TextAlign.left,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 302,
                                          width: 54,
                                          top: 232,
                                          height: 21,
                                          child: Container(
                                            width: 54,
                                            height: 21,
                                            decoration: BoxDecoration(
                                              color: const Color(0xff6e0b2a),
                                              border: Border.all(color: const Color(0xffa21441), width: 1),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  left: 0,
                                                  width: 54,
                                                  top: 0,
                                                  height: 21,
                                                  child: Text(
                                                    'Donate',
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                    maxLines: 9999,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 11),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    height: 264,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 0,
                                          width: 378,
                                          top: 0,
                                          height: 264,
                                          child: Container(
                                            width: 378,
                                            height: 264,
                                            decoration: BoxDecoration(
                                              color: const Color(0xffffffff),
                                              border: Border.all(color: const Color(0xfff3767c), width: 1),
                                              borderRadius: BorderRadius.circular(15),
                                            ),
                                          ),
                                        ),
                                        Positioned(
                                          left: 34,
                                          width: 336,
                                          top: 28,
                                          child: Text(
                                            'Name: John Wayne Items:  10 Instant noodles  20 Bottled water   Phone number: 016-7254589 Address: 12, Jalan Ampang, Kampung Baru,  50450 Kuala Lumpur, Malaysia Link to address: ',
                                            textAlign: TextAlign.left,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 302,
                                          width: 54,
                                          top: 224,
                                          height: 21,
                                          child: Container(
                                            width: 54,
                                            height: 21,
                                            decoration: BoxDecoration(
                                              color: const Color(0xff6e0b2a),
                                              border: Border.all(color: const Color(0xffa21441), width: 1),
                                              borderRadius: BorderRadius.circular(5),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  left: 0,
                                                  width: 54,
                                                  top: 0,
                                                  height: 21,
                                                  child: Text(
                                                    'Donate',
                                                    textAlign: TextAlign.center,
                                                    style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                    maxLines: 9999,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 2021,
              width: 430,
              top: 1200,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 110,
                      width: 332,
                      top: -196,
                      height: 330,
                      child: Image.asset('images/image1_126398.png', width: 332, height: 330,),
                    ),
                    Positioned(
                      left: -189,
                      width: 487,
                      top: -165,
                      height: 432,
                      child: Image.asset('images/image2_126399.png', width: 487, height: 432,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image3_126400.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 459,
                      width: 626,
                      top: 99,
                      height: 417,
                      child: Image.asset('images/image4_126401.png', width: 626, height: 417, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 22,
                      width: 378,
                      top: 399,
                      height: 192,
                      child: Container(
                        width: 378,
                        height: 192,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xfff3767c), width: 1),
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 22,
                      width: 151,
                      top: 399,
                      height: 192,
                      child: Image.asset('images/image5_129260.png', width: 151, height: 192, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 22,
                      width: 378,
                      top: 620,
                      height: 192,
                      child: Container(
                        width: 378,
                        height: 192,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xfff3767c), width: 1),
                          borderRadius: BorderRadius.circular(15),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 22,
                      width: 151,
                      top: 620,
                      height: 192,
                      child: Image.asset('images/image6_129264.png', width: 151, height: 192, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I12642412871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image7_126515.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79.25,
                      height: 22.5,
                      child: Image.asset('images/image8_126516.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image9_126519.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image10_126520.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 26,
                      width: 257,
                      top: 128,
                      height: 64,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 43,
                            child: Text(
                              'Sarah Suhairi',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 40, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 2,
                            width: 39,
                            top: 0,
                            height: 29,
                            child: Text(
                              'Hi,',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 30, color: const Color(0xff6e0b2a), fontFamily: 'Kantumruy-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 22,
                      width: 376.975,
                      top: 243,
                      height: 125,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            width: 96.876,
                            top: 0,
                            height: 92.48,
                            child: Container(
                              width: 96.876,
                              height: 92.48,
                              decoration: BoxDecoration(
                                color: const Color(0xffffdde3),
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 143.208,
                            width: 96.876,
                            top: 0,
                            height: 92.48,
                            child: Container(
                              width: 96.876,
                              height: 92.48,
                              decoration: BoxDecoration(
                                color: const Color(0xffffdee3),
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 280.099,
                            width: 96.876,
                            top: 0,
                            height: 92.48,
                            child: Container(
                              width: 96.876,
                              height: 92.48,
                              decoration: BoxDecoration(
                                color: const Color(0xffffdee3),
                                borderRadius: BorderRadius.circular(15),
                              ),
                            ),
                          ),
                          Positioned(
                            left: 296.946,
                            width: 63.18,
                            top: 20.325,
                            height: 52.846,
                            child: Image.asset('images/image1_126534.png', width: 63.18, height: 52.846,),
                          ),
                          Positioned(
                            left: 15.795,
                            width: 65.286,
                            top: 16.26,
                            height: 59.959,
                            child: Image.asset('images/image2_126544.png', width: 65.286, height: 59.959,),
                          ),
                          Positioned(
                            left: 160.056,
                            width: 63.18,
                            top: 16.26,
                            height: 59.959,
                            child: Image.asset('images/image3_126556.png', width: 63.18, height: 59.959,),
                          ),
                          Positioned(
                            left: 0,
                            width: 96.876,
                            top: 96.545,
                            height: 28.455,
                            child: Text(
                              'Account Info',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff7c2a44), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 159.003,
                            width: 64.233,
                            top: 96.545,
                            height: 28.455,
                            child: Text(
                              'Rewards',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff7c2a44), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 296.946,
                            width: 62.127,
                            top: 96.545,
                            height: 28.455,
                            child: Text(
                              'Settings',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff7c2a44), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image11_126567.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image12_126570.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image13_126571.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 180,
                      width: 165,
                      top: 628,
                      height: 32,
                      child: Text(
                        'Request History',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xff7c2a44), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 322,
                      top: 570,
                      child: Text(
                        'View Details',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffa21441), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 322,
                      top: 791,
                      child: Text(
                        'View Details',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffa21441), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 178,
                      width: 178,
                      top: 402,
                      height: 136,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 2,
                            width: 176,
                            top: 0,
                            height: 32,
                            child: Text(
                              'Donation History',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xff7c2a44), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 0,
                            width: 140,
                            top: 42,
                            height: 94,
                            child: Stack(
                              children: [
                                Positioned(
                                  left: 0,
                                  width: 140,
                                  top: 0,
                                  height: 94,
                                  child: Stack(
                                    children: [
                                      Positioned(
                                        left: 5,
                                        width: 89,
                                        top: 0,
                                        height: 24,
                                        child: Text(
                                          'Total Donations:',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                          maxLines: 9999,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      Positioned(
                                        left: 2,
                                        width: 126,
                                        top: 48,
                                        height: 20,
                                        child: Text(
                                          'Recent Donation Date:',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                          maxLines: 9999,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      Positioned(
                                        left: 1,
                                        width: 139,
                                        top: 73,
                                        height: 21,
                                        child: Text(
                                          'Recent Donation Status:',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                          maxLines: 9999,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                      Positioned(
                                        left: 0,
                                        width: 105,
                                        top: 24,
                                        height: 16,
                                        child: Text(
                                          'Total Receipients:',
                                          textAlign: TextAlign.center,
                                          style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                          maxLines: 9999,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 180,
                      width: 127,
                      top: 670,
                      height: 88,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            width: 80,
                            top: 0,
                            height: 19,
                            child: Text(
                              'Total Request:',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 4,
                            top: 44,
                            child: Text(
                              'Recent Request Date:',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 4,
                            top: 67,
                            child: Text(
                              'Recent Request Status:',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 3,
                            top: 21,
                            child: Text(
                              'Total Donors:',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 2491,
              width: 430,
              top: 1200,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 110,
                      width: 332,
                      top: -196,
                      height: 330,
                      child: Image.asset('images/image1_137263.png', width: 332, height: 330,),
                    ),
                    Positioned(
                      left: -210,
                      width: 487,
                      top: -166,
                      height: 432,
                      child: Image.asset('images/image2_137264.png', width: 487, height: 432,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image3_137265.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 459,
                      width: 626,
                      top: 99,
                      height: 417,
                      child: Image.asset('images/image4_137266.png', width: 626, height: 417, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I13727112871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image5_137272.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79.25,
                      height: 22.5,
                      child: Image.asset('images/image6_137273.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image7_137276.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image8_137277.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image9_137298.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image10_137301.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image11_137302.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 23,
                      width: 334,
                      top: 130,
                      height: 64,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 43,
                            child: Text(
                              'Donation History',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 40, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Text(
                              'View',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 30, color: const Color(0xff6e0b2a), fontFamily: 'Kantumruy-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 147,
                      width: 107,
                      top: 223,
                      height: 21,
                      child: Container(
                        width: 107,
                        height: 21,
                        decoration: BoxDecoration(
                          color: const Color(0xff6e0b2a),
                          border: Border.all(color: const Color(0xffa21441), width: 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 107,
                              top: 0,
                              height: 21,
                              child: Text(
                                'Community',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 25,
                      width: 106,
                      top: 223,
                      height: 21,
                      child: Container(
                        width: 106,
                        height: 21,
                        decoration: BoxDecoration(
                          color: const Color(0xff6e0b2a),
                          border: Border.all(color: const Color(0xffa21441), width: 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 106,
                              top: 0,
                              height: 21,
                              child: Text(
                                'Individual',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 19,
                      width: 386,
                      top: 258,
                      height: 579,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 5, top: 3, right: 5, bottom: 3),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    height: 264,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 0,
                                          width: 378,
                                          top: 0,
                                          height: 264,
                                          child: Container(
                                            width: 378,
                                            height: 264,
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(15),
                                            ),
                                            child: Stack(
                                              children: [
                                                Positioned(
                                                  left: 0,
                                                  width: 378,
                                                  top: 0,
                                                  height: 264,
                                                  child: Container(
                                                    width: 378,
                                                    height: 264,
                                                    decoration: BoxDecoration(
                                                      borderRadius: BorderRadius.circular(15),
                                                    ),
                                                    child: Stack(
                                                      children: [
                                                        Positioned(
                                                          left: 0,
                                                          width: 378,
                                                          top: 0,
                                                          height: 264,
                                                          child: Container(
                                                            width: 378,
                                                            height: 264,
                                                            decoration: BoxDecoration(
                                                              color: const Color(0xffffffff),
                                                              border: Border.all(color: const Color(0xfff3767c), width: 1),
                                                              borderRadius: BorderRadius.circular(15),
                                                            ),
                                                          ),
                                                        ),
                                                        Positioned(
                                                          left: 27,
                                                          width: 331,
                                                          top: 19,
                                                          height: 201,
                                                          child: Stack(
                                                            children: [
                                                              Positioned(
                                                                left: 0,
                                                                top: 0,
                                                                child: Text(
                                                                  'Emily Aster',
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xff7c2a44), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                                                                  maxLines: 9999,
                                                                  overflow: TextOverflow.ellipsis,
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 2,
                                                                top: 54,
                                                                child: Text(
                                                                  'Phone number: 018-49862746',
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                  maxLines: 9999,
                                                                  overflow: TextOverflow.ellipsis,
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 0,
                                                                top: 180,
                                                                child: Text(
                                                                  'Donation tracking:',
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                  maxLines: 9999,
                                                                  overflow: TextOverflow.ellipsis,
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 0,
                                                                top: 157,
                                                                child: Text(
                                                                  'Request Details: 5 Cereal boxes, 6 Milk cartons, 5 baby formula',
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                  maxLines: 9999,
                                                                  overflow: TextOverflow.ellipsis,
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 0,
                                                                top: 134,
                                                                child: Text(
                                                                  'Donation date:',
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                  maxLines: 9999,
                                                                  overflow: TextOverflow.ellipsis,
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 2,
                                                                top: 76,
                                                                child: Text(
                                                                  'Address: 12, Jalan Ampang, Kampung Baru,  ',
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                  maxLines: 9999,
                                                                  overflow: TextOverflow.ellipsis,
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 51,
                                                                top: 92,
                                                                child: Text(
                                                                  '50450 Kuala Lumpur, Malaysia',
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                  maxLines: 9999,
                                                                  overflow: TextOverflow.ellipsis,
                                                                ),
                                                              ),
                                                              Positioned(
                                                                left: 0,
                                                                top: 113,
                                                                child: Text(
                                                                  'Link to address:',
                                                                  textAlign: TextAlign.center,
                                                                  style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                  maxLines: 9999,
                                                                  overflow: TextOverflow.ellipsis,
                                                                ),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 23),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    height: 264,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 0,
                                          width: 378,
                                          top: 0,
                                          height: 264,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                left: 72.025,
                                                width: 1.174,
                                                top: 109.877,
                                                height: 1.174,
                                                child: Image.asset('images/image_171461.png', width: 1.174, height: 1.174,),
                                              ),
                                              Positioned(
                                                left: 0,
                                                width: 378,
                                                top: 0,
                                                height: 264,
                                                child: Container(
                                                  width: 378,
                                                  height: 264,
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(15),
                                                  ),
                                                  child: Stack(
                                                    children: [
                                                      Positioned(
                                                        left: 0,
                                                        width: 378,
                                                        top: 0,
                                                        height: 264,
                                                        child: Container(
                                                          width: 378,
                                                          height: 264,
                                                          decoration: BoxDecoration(
                                                            color: const Color(0xffffffff),
                                                            border: Border.all(color: const Color(0xfff3767c), width: 1),
                                                            borderRadius: BorderRadius.circular(15),
                                                          ),
                                                        ),
                                                      ),
                                                      Positioned(
                                                        left: 12,
                                                        width: 305,
                                                        top: 23,
                                                        height: 197,
                                                        child: Stack(
                                                          children: [
                                                            Positioned(
                                                              left: 17,
                                                              top: 0,
                                                              child: Text(
                                                                'John Wayne',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xff7c2a44), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 17,
                                                              top: 50,
                                                              child: Text(
                                                                'Phone number: 016-7254589',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 15,
                                                              top: 176,
                                                              child: Text(
                                                                'Donation tracking:',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 14,
                                                              top: 153,
                                                              child: Text(
                                                                'Request Details: 2 Rice bags, 5 Cooking oil',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 15,
                                                              top: 130,
                                                              child: Text(
                                                                'Donation date:',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 0,
                                                              width: 305,
                                                              top: 71,
                                                              height: 24,
                                                              child: Text(
                                                                'Address: 12, Jalan Ampang, Kampung  Baru, 50450 ',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 65,
                                                              top: 86,
                                                              child: Text(
                                                                'Kuala Lumpur, Malaysia',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                            Positioned(
                                                              left: 15,
                                                              top: 109,
                                                              child: Text(
                                                                'Link to address:',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 19,
                      width: 38,
                      top: 72,
                      height: 32,
                      child: Image.asset('images/image12_311771.png', width: 38, height: 32,),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 2946,
              width: 430,
              top: 1200,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 110,
                      width: 332,
                      top: -196,
                      height: 330,
                      child: Image.asset('images/image1_287438.png', width: 332, height: 330,),
                    ),
                    Positioned(
                      left: -210,
                      width: 487,
                      top: -166,
                      height: 432,
                      child: Image.asset('images/image2_287439.png', width: 487, height: 432,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image3_287440.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 459,
                      width: 626,
                      top: 99,
                      height: 417,
                      child: Image.asset('images/image4_287441.png', width: 626, height: 417, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I28744212871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image5_287443.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79.25,
                      height: 22.5,
                      child: Image.asset('images/image6_287444.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image7_287447.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image8_287448.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image9_287450.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image10_287453.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image11_287454.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 23,
                      width: 334,
                      top: 130,
                      height: 64,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 43,
                            child: Text(
                              'Donation History',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 40, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Text(
                              'View',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 30, color: const Color(0xff6e0b2a), fontFamily: 'Kantumruy-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 40,
                      width: 349,
                      top: 266,
                      height: 393,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 5, top: 3, right: 5, bottom: 3),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 339,
                              height: 387,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    width: 339,
                                    top: 0,
                                    height: 387,
                                    child: Container(
                                      width: 339,
                                      height: 387,
                                      decoration: BoxDecoration(
                                        color: const Color(0xffffffff),
                                        border: Border.all(color: const Color(0xfff3767c), width: 1),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 0,
                                    width: 339,
                                    top: 0,
                                    height: 185,
                                    child: Image.asset('images/image_300680.png', width: 339, height: 185, fit: BoxFit.cover,),
                                  ),
                                  Positioned(
                                    left: 19.875,
                                    width: 208.125,
                                    top: 195,
                                    height: 176,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 1.125,
                                          top: 0,
                                          child: Text(
                                            'Help flood victim',
                                            textAlign: TextAlign.left,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 26.125,
                                          top: 31,
                                          child: Text(
                                            'Jabatan Kebajikan Sarawak',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 26.125,
                                          top: 62,
                                          child: Text(
                                            'Kampung Semarang Community',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 26.125,
                                          top: 93,
                                          child: Text(
                                            '4 days left',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 26.125,
                                          top: 124,
                                          child: Text(
                                            'Donation Date:',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 26.125,
                                          top: 155,
                                          child: Text(
                                            'Donation Tracking:',
                                            textAlign: TextAlign.center,
                                            style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                            maxLines: 9999,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                        ),
                                        Positioned(
                                          left: 1.311,
                                          width: 16.142,
                                          top: 31,
                                          height: 17,
                                          child: Image.asset('images/image1_300688.png', width: 16.142, height: 17,),
                                        ),
                                        Positioned(
                                          left: 1.311,
                                          width: 16.142,
                                          top: 65,
                                          height: 15,
                                          child: Image.asset('images/image2_300689.png', width: 16.142, height: 15,),
                                        ),
                                        Positioned(
                                          left: 1.311,
                                          width: 16.142,
                                          top: 97,
                                          height: 13,
                                          child: Image.asset('images/image3_300690.png', width: 16.142, height: 13,),
                                        ),
                                        Positioned(
                                          left: 9.385,
                                          width: 3.422,
                                          top: 99.6,
                                          height: 6.659,
                                          child: Image.asset('images/image4_300691.png', width: 3.422, height: 6.659,),
                                        ),
                                        Positioned(
                                          left: 0,
                                          width: 18.783,
                                          top: 155.833,
                                          height: 18.333,
                                          child: Image.asset('images/image5_300692.png', width: 18.783, height: 18.333,),
                                        ),
                                        Positioned(
                                          left: 1.125,
                                          width: 16,
                                          top: 127,
                                          height: 14,
                                          child: Image.asset('images/image6_300693.png', width: 16, height: 14,),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 24,
                      width: 106,
                      top: 223,
                      height: 21,
                      child: Container(
                        width: 106,
                        height: 21,
                        decoration: BoxDecoration(
                          color: const Color(0xff6e0b2a),
                          border: Border.all(color: const Color(0xffa21441), width: 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 106,
                              top: 0,
                              height: 21,
                              child: Text(
                                'Individual',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 146,
                      width: 107,
                      top: 223,
                      height: 21,
                      child: Container(
                        width: 107,
                        height: 21,
                        decoration: BoxDecoration(
                          color: const Color(0xff6e0b2a),
                          border: Border.all(color: const Color(0xffa21441), width: 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 107,
                              top: 0,
                              height: 21,
                              child: Text(
                                'Community',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 19,
                      width: 38,
                      top: 72,
                      height: 32,
                      child: Image.asset('images/image12_311774.png', width: 38, height: 32,),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 3416,
              width: 430,
              top: 1200,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 110,
                      width: 332,
                      top: -196,
                      height: 330,
                      child: Image.asset('images/image1_137458.png', width: 332, height: 330,),
                    ),
                    Positioned(
                      left: -210,
                      width: 487,
                      top: -166,
                      height: 432,
                      child: Image.asset('images/image2_137459.png', width: 487, height: 432,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image3_137460.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 459,
                      width: 626,
                      top: 99,
                      height: 417,
                      child: Image.asset('images/image4_137461.png', width: 626, height: 417, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I13746212871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image5_137463.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79.25,
                      height: 22.5,
                      child: Image.asset('images/image6_137464.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image7_137467.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image8_137468.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image9_137470.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image10_137473.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image11_137474.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 23,
                      width: 305,
                      top: 130,
                      height: 65,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 44,
                            child: Text(
                              'Request History',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 40, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Text(
                              'View',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 30, color: const Color(0xff6e0b2a), fontFamily: 'Kantumruy-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 16,
                      width: 392,
                      top: 266,
                      height: 571,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 4, top: 3, right: 4, bottom: 3),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 378,
                              height: 211,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    width: 378,
                                    top: 0,
                                    height: 211,
                                    child: Container(
                                      width: 378,
                                      height: 211,
                                      decoration: BoxDecoration(
                                        color: const Color(0xffffffff),
                                        border: Border.all(color: const Color(0xfff3767c), width: 1),
                                        borderRadius: BorderRadius.circular(15),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 24,
                                    top: 16,
                                    child: Text(
                                      'Sarah Suhari',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xff7c2a44), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 26,
                                    top: 65,
                                    child: Text(
                                      'Phone number: 012-3456789',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 26,
                                    top: 170,
                                    child: Text(
                                      'Request Status: In Progress',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 24,
                                    top: 147,
                                    child: Text(
                                      'Request Details: 2 Rice bags, 5 Cooking oil',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 24,
                                    width: 305,
                                    top: 86,
                                    height: 24,
                                    child: Text(
                                      'Address: 18, Jalan Kebun, Seksyen 30, 40460 Shah Alam,  ',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 74,
                                    top: 101,
                                    child: Text(
                                      'Selangor, Malaysia',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 24,
                                    top: 124,
                                    child: Text(
                                      'Link to address:',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 23,
                      width: 106,
                      top: 223,
                      height: 21,
                      child: Container(
                        width: 106,
                        height: 21,
                        decoration: BoxDecoration(
                          color: const Color(0xff6e0b2a),
                          border: Border.all(color: const Color(0xffa21441), width: 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 106,
                              top: 0,
                              height: 21,
                              child: Text(
                                'Individual',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 146,
                      width: 107,
                      top: 223,
                      height: 21,
                      child: Container(
                        width: 107,
                        height: 21,
                        decoration: BoxDecoration(
                          color: const Color(0xff6e0b2a),
                          border: Border.all(color: const Color(0xffa21441), width: 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 107,
                              top: 0,
                              height: 21,
                              child: Text(
                                'Community',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 19,
                      width: 38,
                      top: 72,
                      height: 32,
                      child: Image.asset('images/image12_311777.png', width: 38, height: 32,),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 3904,
              width: 430,
              top: 1200,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 110,
                      width: 332,
                      top: -196,
                      height: 330,
                      child: Image.asset('images/image1_296817.png', width: 332, height: 330,),
                    ),
                    Positioned(
                      left: -210,
                      width: 487,
                      top: -166,
                      height: 432,
                      child: Image.asset('images/image2_296818.png', width: 487, height: 432,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image3_296819.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 459,
                      width: 626,
                      top: 99,
                      height: 417,
                      child: Image.asset('images/image4_296820.png', width: 626, height: 417, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I29682112871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image5_296822.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79.25,
                      height: 22.5,
                      child: Image.asset('images/image6_296823.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image7_296826.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image8_296827.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image9_296829.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image10_296832.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image11_296833.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 23,
                      width: 305,
                      top: 130,
                      height: 65,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 44,
                            child: Text(
                              'Request History',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 40, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Text(
                              'View',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 30, color: const Color(0xff6e0b2a), fontFamily: 'Kantumruy-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 39,
                      width: 352,
                      top: 266,
                      height: 571,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 5, top: 3, right: 5, bottom: 3),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 339,
                              height: 376,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    width: 339,
                                    top: 0,
                                    height: 376,
                                    child: Container(
                                      width: 339,
                                      height: 376,
                                      decoration: BoxDecoration(
                                        color: const Color(0xffffffff),
                                        border: Border.all(color: const Color(0xfff3767c), width: 1),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 45,
                                    top: 319,
                                    child: Text(
                                      'Request date: 20 October 2024',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 21,
                                    top: 195,
                                    child: Text(
                                      'Care2Share campaign',
                                      textAlign: TextAlign.left,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 46,
                                    top: 229,
                                    child: Text(
                                      'Care2Share',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 46,
                                    top: 257,
                                    child: Text(
                                      'Students Community',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 46,
                                    top: 288,
                                    child: Text(
                                      '4 days left',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 0,
                                    width: 339,
                                    top: 0,
                                    height: 185,
                                    child: Image.asset('images/image1_294656.png', width: 339, height: 185, fit: BoxFit.cover,),
                                  ),
                                  Positioned(
                                    left: 21.186,
                                    width: 16.142,
                                    top: 226,
                                    height: 17,
                                    child: Image.asset('images/image2_294658.png', width: 16.142, height: 17,),
                                  ),
                                  Positioned(
                                    left: 21.186,
                                    width: 16.142,
                                    top: 260,
                                    height: 15,
                                    child: Image.asset('images/image3_294659.png', width: 16.142, height: 15,),
                                  ),
                                  Positioned(
                                    left: 21.186,
                                    width: 16.142,
                                    top: 292,
                                    height: 13,
                                    child: Image.asset('images/image4_294660.png', width: 16.142, height: 13,),
                                  ),
                                  Positioned(
                                    left: 18,
                                    width: 306,
                                    top: 356,
                                    height: 11,
                                    child: Image.asset('images/image5_294664.png', width: 306, height: 11,),
                                  ),
                                  Positioned(
                                    left: 21,
                                    width: 16,
                                    top: 322,
                                    height: 14,
                                    child: Image.asset('images/image6_296871.png', width: 16, height: 14,),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 36),
                            SizedBox(
                              width: 339,
                              height: 376,
                              child: Stack(
                                children: [
                                  Positioned(
                                    left: 0,
                                    width: 339,
                                    top: 0,
                                    height: 376,
                                    child: Container(
                                      width: 339,
                                      height: 376,
                                      decoration: BoxDecoration(
                                        color: const Color(0xffffffff),
                                        border: Border.all(color: const Color(0xfff3767c), width: 1),
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                    left: 21,
                                    top: 195,
                                    child: Text(
                                      'One act, zero hunger',
                                      textAlign: TextAlign.left,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 46,
                                    top: 229,
                                    child: Text(
                                      'Hacktivate',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 46,
                                    top: 257,
                                    child: Text(
                                      'Donation to Public',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 47,
                                    top: 288,
                                    child: Text(
                                      '100 days left',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 0,
                                    width: 339,
                                    top: 0,
                                    height: 185,
                                    child: Image.asset('images/image1_294674.png', width: 339, height: 185, fit: BoxFit.cover,),
                                  ),
                                  Positioned(
                                    left: 21.186,
                                    width: 16.142,
                                    top: 226,
                                    height: 17,
                                    child: Image.asset('images/image2_294676.png', width: 16.142, height: 17,),
                                  ),
                                  Positioned(
                                    left: 21.186,
                                    width: 16.142,
                                    top: 260,
                                    height: 15,
                                    child: Image.asset('images/image3_294677.png', width: 16.142, height: 15,),
                                  ),
                                  Positioned(
                                    left: 21.186,
                                    width: 16.142,
                                    top: 292,
                                    height: 13,
                                    child: Image.asset('images/image4_294678.png', width: 16.142, height: 13,),
                                  ),
                                  Positioned(
                                    left: 47,
                                    top: 319,
                                    child: Text(
                                      'Request date: 31 August 2024',
                                      textAlign: TextAlign.center,
                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                      maxLines: 9999,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  Positioned(
                                    left: 17,
                                    width: 306,
                                    top: 356,
                                    height: 11,
                                    child: Image.asset('images/image5_296886.png', width: 306, height: 11,),
                                  ),
                                  Positioned(
                                    left: 20,
                                    width: 16,
                                    top: 322,
                                    height: 14,
                                    child: Image.asset('images/image6_296888.png', width: 16, height: 14,),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 23,
                      width: 106,
                      top: 220,
                      height: 21,
                      child: Container(
                        width: 106,
                        height: 21,
                        decoration: BoxDecoration(
                          color: const Color(0xff6e0b2a),
                          border: Border.all(color: const Color(0xffa21441), width: 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 106,
                              top: 0,
                              height: 21,
                              child: Text(
                                'Individual',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 146,
                      width: 107,
                      top: 220,
                      height: 21,
                      child: Container(
                        width: 107,
                        height: 21,
                        decoration: BoxDecoration(
                          color: const Color(0xff6e0b2a),
                          border: Border.all(color: const Color(0xffa21441), width: 1),
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 107,
                              top: 0,
                              height: 21,
                              child: Text(
                                'Community',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 19,
                      width: 38,
                      top: 72,
                      height: 32,
                      child: Image.asset('images/image12_311780.png', width: 38, height: 32,),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 1790,
              width: 430,
              top: 0,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xefffbbbb),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: -110,
                      width: 672,
                      top: -104,
                      height: 570,
                      child: Image.asset('images/image1_77337.png', width: 672, height: 570,),
                    ),
                    Positioned(
                      left: -31,
                      width: 593,
                      top: -120,
                      height: 387,
                      child: Container(
                        width: 593,
                        height: 387,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image2_77308.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I7730712871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 54,
                      width: 319,
                      top: 546,
                      height: 273,
                      child: Container(
                        width: 319,
                        height: 273,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 4,
                              width: 315,
                              top: 219,
                              height: 54,
                              child: Container(
                                width: 315,
                                height: 54,
                                decoration: BoxDecoration(
                                  color: const Color(0xfffff6e7),
                                  border: Border.all(color: const Color(0xfff3767c), width: 1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 4,
                              width: 315,
                              top: 127,
                              height: 54,
                              child: Container(
                                width: 315,
                                height: 54,
                                decoration: BoxDecoration(
                                  color: const Color(0x35ffffff),
                                  border: Border.all(color: const Color(0xff000000), width: 1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 4,
                              width: 315,
                              top: 28,
                              height: 54,
                              child: Container(
                                width: 315,
                                height: 54,
                                decoration: BoxDecoration(
                                  color: const Color(0xffffffff),
                                  border: Border.all(color: const Color(0xfff3767c), width: 1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 4,
                              width: 315,
                              top: 127,
                              height: 54,
                              child: Container(
                                width: 315,
                                height: 54,
                                decoration: BoxDecoration(
                                  color: const Color(0x35ffffff),
                                  border: Border.all(color: const Color(0xff000000), width: 1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 4,
                              width: 315,
                              top: 127,
                              height: 54,
                              child: Container(
                                width: 315,
                                height: 54,
                                decoration: BoxDecoration(
                                  color: const Color(0x35ffffff),
                                  border: Border.all(color: const Color(0xff000000), width: 1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 4,
                              width: 315,
                              top: 127,
                              height: 54,
                              child: Container(
                                width: 315,
                                height: 54,
                                decoration: BoxDecoration(
                                  color: const Color(0xffffffff),
                                  border: Border.all(color: const Color(0xfff3767c), width: 1),
                                  borderRadius: BorderRadius.circular(30),
                                ),
                              ),
                            ),
                            Positioned(
                              left: 98,
                              width: 122,
                              top: 238,
                              height: 16,
                              child: Text(
                                'Sign In',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 6.4, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Positioned(
                              left: 0,
                              width: 90,
                              top: 0,
                              height: 18,
                              child: Text(
                                'USERNAME',
                                textAlign: TextAlign.left,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 5.4, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Medium', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Positioned(
                              left: 0,
                              width: 123,
                              top: 101,
                              height: 16,
                              child: Text(
                                'PASSWORD',
                                textAlign: TextAlign.left,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 4.8, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Medium', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 116,
                      width: 198,
                      top: 428,
                      height: 92,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            width: 198,
                            top: 0,
                            height: 53,
                            child: Text(
                              'Sign In',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 52, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 27,
                            top: 42,
                            child: Text(
                              'Sign in to continue.',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 15, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 109,
                      width: 214,
                      top: 187,
                      height: 215,
                      child: Image.asset('images/image3_86236.png', width: 214, height: 215, fit: BoxFit.cover,),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 0,
              width: 430,
              top: 0,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xfff8f5f0),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                  boxShadow: const [BoxShadow(color: const Color(0x3f000000), offset: Offset(0, 4), blurRadius: 4),],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 497.5,
                      width: 430,
                      top: 2,
                      height: 928,
                      child: Image.asset('images/image1_102301.png', width: 430, height: 928,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 2,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I10230212871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 15,
                      width: 400,
                      top: 266,
                      height: 400,
                      child: Image.asset('images/image2_102303.png', width: 400, height: 400, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 166,
                      top: 608,
                      child: Text(
                        'Click Here !',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff314605), fontFamily: 'KaiseiOpti-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 0,
              width: 430,
              top: 898,
              height: 34,
              child: Image.asset('images/image_102305.png', width: 430, height: 34,),
            ),
            Positioned(
              left: 571,
              width: 430,
              top: 0,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xfff8f5f0),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 1,
                      height: 596,
                      child: Container(
                        width: 430,
                        height: 596,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(3),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 932,
                      child: Image.asset('images/image1_102322.png', width: 430, height: 932,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I10232312871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image2_102324.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 22,
                      width: 387,
                      top: 271,
                      height: 195,
                      child: Text(
                        'Fighting Hunger     with    Every Click',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 48, color: const Color(0xff111111), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 214,
                      width: 147,
                      top: 796,
                      child: Text(
                        'Get Started',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 22,
                      width: 387,
                      top: 487,
                      height: 49,
                      child: Text(
                        'From your hands to their tables',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Medium', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 351,
                      width: 45,
                      top: 800,
                      height: 44,
                      child: Image.asset('images/image3_102328.png', width: 45, height: 44,),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 1197,
              width: 430,
              top: 0,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffbbbb),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: -31,
                      width: 593,
                      top: -120,
                      height: 387,
                      child: Container(
                        width: 593,
                        height: 387,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(50),
                        ),
                      ),
                    ),
                    Positioned(
                      left: -110,
                      width: 672,
                      top: -104,
                      height: 570,
                      child: Image.asset('images/image1_281430.png', width: 672, height: 570,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I10234412871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image2_102345.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 77,
                      top: 269,
                      child: Text(
                        'Already Registered? Sign in here.',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 241,
                      width: 108,
                      top: 291,
                      height: 1,
                      child: Image.asset('images/image3_102347.png', width: 108, height: 1,),
                    ),
                    Positioned(
                      left: 20,
                      width: 389,
                      top: 213,
                      height: 68,
                      child: Text(
                        'Create Account',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 48, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 57,
                      width: 315,
                      top: 341,
                      height: 378,
                      child: Container(
                        width: 315,
                        height: 378,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 315,
                              top: 26,
                              height: 253,
                              child: Image.asset('images/image1_102348.png', width: 315, height: 253,),
                            ),
                            Positioned(
                              left: 0,
                              width: 315,
                              top: 324,
                              height: 54,
                              child: Image.asset('images/image2_102352.png', width: 315, height: 54,),
                            ),
                            Positioned(
                              left: 0,
                              width: 315,
                              top: 125,
                              height: 54,
                              child: Image.asset('images/image3_102354.png', width: 315, height: 54,),
                            ),
                            Positioned(
                              left: 0,
                              width: 90,
                              top: 0,
                              height: 18,
                              child: Text(
                                'EMAIL',
                                textAlign: TextAlign.left,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 5.4, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Medium', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Positioned(
                              left: 0,
                              width: 90,
                              top: 99,
                              height: 18,
                              child: Text(
                                'USERNAME',
                                textAlign: TextAlign.left,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 5.4, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Medium', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Positioned(
                              left: 0,
                              width: 104,
                              top: 199,
                              height: 18,
                              child: Text(
                                'PASSWORD',
                                textAlign: TextAlign.left,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 5.4, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Medium', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Positioned(
                              left: 111,
                              width: 93,
                              top: 342,
                              height: 18,
                              child: Text(
                                'Sign Up',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 7.2, color: const Color(0xff000000), fontFamily: 'KaiseiOpti-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 3333,
              width: 430,
              top: 0,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 252,
                      child: Container(
                        width: 430,
                        height: 252,
                        decoration: BoxDecoration(
                          color: const Color(0x68ffbbbb),
                          border: Border.all(color: const Color(0xd2ffcc99), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I11139412871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image1_111395.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image2_111396.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79.25,
                      height: 22.5,
                      child: Image.asset('images/image3_111397.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image4_111400.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image5_111401.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 31,
                      width: 45,
                      top: 70,
                      height: 44,
                      child: Image.asset('images/image6_111402.png', width: 45, height: 44, fit: BoxFit.cover,),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image7_111403.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image8_111406.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image9_111407.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 31,
                      width: 399,
                      top: 127,
                      child: Image.asset('images/image10_277489.png', width: 399,),
                    ),
                    Positioned(
                      left: 84,
                      width: 102,
                      top: 358,
                      height: 25,
                      child: Container(
                        width: 102,
                        height: 25,
                        decoration: BoxDecoration(
                          color: const Color(0xfff8f5f0),
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: const [BoxShadow(color: const Color(0x3f000000), offset: Offset(0, 4), blurRadius: 4),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 98,
                      top: 359,
                      child: Text(
                        'Individual',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff000000), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 247,
                      width: 103,
                      top: 359,
                      height: 25,
                      child: Container(
                        width: 103,
                        height: 25,
                        decoration: BoxDecoration(
                          color: const Color(0xfff8f5f0),
                          borderRadius: BorderRadius.circular(7),
                          boxShadow: const [BoxShadow(color: const Color(0x3f000000), offset: Offset(0, 4), blurRadius: 4),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 256,
                      top: 359,
                      child: Text(
                        'Community',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 14, color: const Color(0xff000000), fontFamily: 'Kadwa-Bold', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 39,
                      width: 352,
                      top: 407,
                      height: 430,
                      child: Padding(
                        padding: const EdgeInsets.only(left: 5, top: 3, right: 5, bottom: 3),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    height: 376,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 0,
                                          width: 339,
                                          top: 0,
                                          height: 376,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                left: 0,
                                                width: 339,
                                                top: 0,
                                                height: 376,
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      left: 0,
                                                      width: 339,
                                                      top: 0,
                                                      height: 376,
                                                      child: Stack(
                                                        children: [
                                                          Positioned(
                                                            left: 0,
                                                            width: 339,
                                                            top: 0,
                                                            height: 376,
                                                            child: Container(
                                                              width: 339,
                                                              height: 376,
                                                              decoration: BoxDecoration(
                                                                color: const Color(0xffffffff),
                                                                border: Border.all(color: const Color(0xfff3767c), width: 1),
                                                                borderRadius: BorderRadius.circular(8),
                                                              ),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 21,
                                                            top: 195,
                                                            child: Text(
                                                              'Help flood victim',
                                                              textAlign: TextAlign.left,
                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                                                              maxLines: 9999,
                                                              overflow: TextOverflow.ellipsis,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 46,
                                                            top: 226,
                                                            child: Text(
                                                              'Jabatan Kebajikan Sarawak',
                                                              textAlign: TextAlign.center,
                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                              maxLines: 9999,
                                                              overflow: TextOverflow.ellipsis,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 46,
                                                            top: 257,
                                                            child: Text(
                                                              'Kampung Semarang Community',
                                                              textAlign: TextAlign.center,
                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                              maxLines: 9999,
                                                              overflow: TextOverflow.ellipsis,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 46,
                                                            top: 288,
                                                            child: Text(
                                                              '4 days left',
                                                              textAlign: TextAlign.center,
                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                              maxLines: 9999,
                                                              overflow: TextOverflow.ellipsis,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 0,
                                                            width: 339,
                                                            top: 0,
                                                            height: 185,
                                                            child: Image.asset('images/image1_239482.png', width: 339, height: 185, fit: BoxFit.cover,),
                                                          ),
                                                          Positioned(
                                                            left: 271,
                                                            width: 54,
                                                            top: 346,
                                                            height: 21,
                                                            child: Container(
                                                              width: 54,
                                                              height: 21,
                                                              decoration: BoxDecoration(
                                                                color: const Color(0xff6e0b2a),
                                                                border: Border.all(color: const Color(0xffa21441), width: 1),
                                                                borderRadius: BorderRadius.circular(5),
                                                              ),
                                                              child: Stack(
                                                                children: [
                                                                  Positioned(
                                                                    left: 0,
                                                                    width: 54,
                                                                    top: 0,
                                                                    height: 21,
                                                                    child: Text(
                                                                      'Donate',
                                                                      textAlign: TextAlign.center,
                                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                      maxLines: 9999,
                                                                      overflow: TextOverflow.ellipsis,
                                                                    ),
                                                                  ),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 271,
                                                            width: 54,
                                                            top: 346,
                                                            height: 21,
                                                            child: Text(
                                                              'Donate',
                                                              textAlign: TextAlign.center,
                                                              style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                              maxLines: 9999,
                                                              overflow: TextOverflow.ellipsis,
                                                            ),
                                                          ),
                                                          Positioned(
                                                            left: 21.186,
                                                            width: 16.142,
                                                            top: 226,
                                                            height: 17,
                                                            child: Image.asset('images/image2_239484.png', width: 16.142, height: 17,),
                                                          ),
                                                          Positioned(
                                                            left: 21.186,
                                                            width: 16.142,
                                                            top: 260,
                                                            height: 15,
                                                            child: Image.asset('images/image3_239485.png', width: 16.142, height: 15,),
                                                          ),
                                                          Positioned(
                                                            left: 21.186,
                                                            width: 16.142,
                                                            top: 292,
                                                            height: 13,
                                                            child: Image.asset('images/image4_239486.png', width: 16.142, height: 13,),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Positioned(
                                                left: 16,
                                                width: 306,
                                                top: 322,
                                                height: 11,
                                                child: Image.asset('images/image_239489.png', width: 306, height: 11,),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 36),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    height: 376,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 0,
                                          width: 339,
                                          top: 0,
                                          height: 376,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                left: 0,
                                                width: 339,
                                                top: 0,
                                                height: 376,
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      left: 0,
                                                      width: 339,
                                                      top: 0,
                                                      height: 376,
                                                      child: Container(
                                                        width: 339,
                                                        height: 376,
                                                        decoration: BoxDecoration(
                                                          color: const Color(0xffffffff),
                                                          border: Border.all(color: const Color(0xfff3767c), width: 1),
                                                          borderRadius: BorderRadius.circular(8),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 21,
                                                      top: 195,
                                                      child: Text(
                                                        'Care2Share campaign',
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                                                        maxLines: 9999,
                                                        overflow: TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 46,
                                                      top: 229,
                                                      child: Text(
                                                        'Universiti Malaysia Sarawak',
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                        maxLines: 9999,
                                                        overflow: TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 46,
                                                      top: 257,
                                                      child: Text(
                                                        'Students Community',
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                        maxLines: 9999,
                                                        overflow: TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 46,
                                                      top: 288,
                                                      child: Text(
                                                        '4 days left',
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                        maxLines: 9999,
                                                        overflow: TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 0,
                                                      width: 339,
                                                      top: 0,
                                                      height: 185,
                                                      child: Image.asset('images/image1_239517.png', width: 339, height: 185, fit: BoxFit.cover,),
                                                    ),
                                                    Positioned(
                                                      left: 271,
                                                      width: 54,
                                                      top: 346,
                                                      height: 21,
                                                      child: Container(
                                                        width: 54,
                                                        height: 21,
                                                        decoration: BoxDecoration(
                                                          color: const Color(0xff6e0b2a),
                                                          border: Border.all(color: const Color(0xffa21441), width: 1),
                                                          borderRadius: BorderRadius.circular(5),
                                                        ),
                                                        child: Stack(
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              width: 54,
                                                              top: 0,
                                                              height: 21,
                                                              child: Text(
                                                                'Donate',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 21.186,
                                                      width: 16.142,
                                                      top: 226,
                                                      height: 17,
                                                      child: Image.asset('images/image2_239519.png', width: 16.142, height: 17,),
                                                    ),
                                                    Positioned(
                                                      left: 21.186,
                                                      width: 16.142,
                                                      top: 260,
                                                      height: 15,
                                                      child: Image.asset('images/image3_239520.png', width: 16.142, height: 15,),
                                                    ),
                                                    Positioned(
                                                      left: 21.186,
                                                      width: 16.142,
                                                      top: 292,
                                                      height: 13,
                                                      child: Image.asset('images/image4_239521.png', width: 16.142, height: 13,),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Positioned(
                                                left: 22,
                                                width: 306,
                                                top: 322,
                                                height: 11,
                                                child: Image.asset('images/image_239524.png', width: 306, height: 11,),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 36),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    height: 376,
                                    child: Stack(
                                      children: [
                                        Positioned(
                                          left: 0,
                                          width: 339,
                                          top: 0,
                                          height: 376,
                                          child: Stack(
                                            children: [
                                              Positioned(
                                                left: 0,
                                                width: 339,
                                                top: 0,
                                                height: 376,
                                                child: Stack(
                                                  children: [
                                                    Positioned(
                                                      left: 0,
                                                      width: 339,
                                                      top: 0,
                                                      height: 376,
                                                      child: Container(
                                                        width: 339,
                                                        height: 376,
                                                        decoration: BoxDecoration(
                                                          color: const Color(0xffffffff),
                                                          border: Border.all(color: const Color(0xfff3767c), width: 1),
                                                          borderRadius: BorderRadius.circular(8),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 21,
                                                      top: 195,
                                                      child: Text(
                                                        'One act, zero hunger',
                                                        textAlign: TextAlign.left,
                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                                                        maxLines: 9999,
                                                        overflow: TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 46,
                                                      top: 229,
                                                      child: Text(
                                                        'Hacktivate',
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                        maxLines: 9999,
                                                        overflow: TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 46,
                                                      top: 257,
                                                      child: Text(
                                                        'Donation to Public',
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                        maxLines: 9999,
                                                        overflow: TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 46,
                                                      top: 288,
                                                      child: Text(
                                                        '4 days left',
                                                        textAlign: TextAlign.center,
                                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xb5000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                        maxLines: 9999,
                                                        overflow: TextOverflow.ellipsis,
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 0,
                                                      width: 339,
                                                      top: 0,
                                                      height: 185,
                                                      child: Image.asset('images/image1_239500.png', width: 339, height: 185, fit: BoxFit.cover,),
                                                    ),
                                                    Positioned(
                                                      left: 271,
                                                      width: 54,
                                                      top: 346,
                                                      height: 21,
                                                      child: Container(
                                                        width: 54,
                                                        height: 21,
                                                        decoration: BoxDecoration(
                                                          color: const Color(0xff6e0b2a),
                                                          border: Border.all(color: const Color(0xffa21441), width: 1),
                                                          borderRadius: BorderRadius.circular(5),
                                                        ),
                                                        child: Stack(
                                                          children: [
                                                            Positioned(
                                                              left: 0,
                                                              width: 54,
                                                              top: 0,
                                                              height: 21,
                                                              child: Text(
                                                                'Donate',
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 12, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                                                maxLines: 9999,
                                                                overflow: TextOverflow.ellipsis,
                                                              ),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 21.186,
                                                      width: 16.142,
                                                      top: 226,
                                                      height: 17,
                                                      child: Image.asset('images/image2_239502.png', width: 16.142, height: 17,),
                                                    ),
                                                    Positioned(
                                                      left: 21.186,
                                                      width: 16.142,
                                                      top: 260,
                                                      height: 15,
                                                      child: Image.asset('images/image3_239503.png', width: 16.142, height: 15,),
                                                    ),
                                                    Positioned(
                                                      left: 21.186,
                                                      width: 16.142,
                                                      top: 292,
                                                      height: 13,
                                                      child: Image.asset('images/image4_239504.png', width: 16.142, height: 13,),
                                                    ),
                                                    Positioned(
                                                      left: 19,
                                                      width: 306,
                                                      top: 322,
                                                      height: 11,
                                                      child: Image.asset('images/image5_239507.png', width: 306, height: 11,),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 3834,
              width: 430,
              top: 0,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 110,
                      width: 332,
                      top: -196,
                      height: 330,
                      child: Image.asset('images/image1_244670.png', width: 332, height: 330,),
                    ),
                    Positioned(
                      left: -210,
                      width: 487,
                      top: -166,
                      height: 432,
                      child: Image.asset('images/image2_244668.png', width: 487, height: 432,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I12534712871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image3_125348.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image4_125349.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image5_125353.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image6_125354.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image7_125356.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image8_125359.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image9_125360.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 571,
                      width: 76,
                      top: 613.5,
                      height: 25,
                      child: Image.asset('images/image10_125394.png', width: 76, height: 25,),
                    ),
                    Positioned(
                      left: 40,
                      width: 342,
                      top: 131,
                      height: 21,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Text(
                              'Request Donation',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 40, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 40,
                      width: 107,
                      top: 211,
                      child: Text(
                        'Full name',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 352,
                      top: 239,
                      height: 49,
                      child: Container(
                        width: 352,
                        height: 49,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 64,
                      top: 247,
                      child: Text(
                        'Sarah Suhari',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 40,
                      width: 134,
                      top: 300,
                      child: Text(
                        'Phone number',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 354,
                      top: 332,
                      height: 49,
                      child: Container(
                        width: 354,
                        height: 49,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 64,
                      width: 207,
                      top: 340,
                      child: Text(
                        '018-49862746',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff111719), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 134,
                      top: 390,
                      child: Text(
                        'Address',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 352,
                      top: 420,
                      height: 66,
                      child: Container(
                        width: 352,
                        height: 66,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 134,
                      top: 494,
                      child: Text(
                        'Link to address',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 134,
                      top: 576,
                      child: Text(
                        'Side note',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 352,
                      top: 526,
                      height: 49,
                      child: Container(
                        width: 352,
                        height: 49,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 352,
                      top: 608,
                      height: 49,
                      child: Container(
                        width: 352,
                        height: 49,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 40,
                      width: 134,
                      top: 174,
                      child: Text(
                        'Category',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 43,
                      width: 107,
                      top: 665,
                      height: 30,
                      child: Text(
                        'Items',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 274,
                      width: 107,
                      top: 668,
                      height: 29,
                      child: Text(
                        'Quantity',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 71,
                      width: 198,
                      top: 694,
                      height: 37,
                      child: Container(
                        width: 198,
                        height: 37,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 274,
                      width: 116,
                      top: 695,
                      height: 36,
                      child: Container(
                        width: 116,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 87,
                      width: 73,
                      top: 697,
                      height: 30,
                      child: Text(
                        'Rice bags',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 71,
                      width: 198,
                      top: 740,
                      height: 37,
                      child: Container(
                        width: 198,
                        height: 37,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 274,
                      width: 116,
                      top: 741,
                      height: 36,
                      child: Container(
                        width: 116,
                        height: 36,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 87,
                      width: 88,
                      top: 744,
                      height: 29,
                      child: Text(
                        'Cooking oil',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 327,
                      width: 10,
                      top: 701,
                      height: 30,
                      child: Text(
                        '2',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 328,
                      top: 742,
                      child: Text(
                        '5',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 61,
                      top: 433,
                      child: Text(
                        '18, Jalan Kebun, Seksyen 30,  40460 Shah Alam, Selangor, Malaysia',
                        textAlign: TextAlign.left,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79,
                      height: 22.5,
                      child: Image.asset('images/image11_195325.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 38,
                      width: 352,
                      top: 787,
                      height: 39,
                      child: Container(
                        width: 352,
                        height: 39,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 352,
                              top: 0,
                              height: 39,
                              child: Container(
                                width: 352,
                                height: 39,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Stack(
                                  children: [
                                    Positioned(
                                      left: 0,
                                      width: 352,
                                      top: 0,
                                      height: 39,
                                      child: Container(
                                        width: 352,
                                        height: 39,
                                        decoration: BoxDecoration(
                                          color: const Color(0xff6e0b2a),
                                          border: Border.all(color: const Color(0xff802642), width: 1),
                                          borderRadius: BorderRadius.circular(10),
                                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      left: 94,
                                      width: 165,
                                      top: 8,
                                      height: 26,
                                      child: Text(
                                        'Submit',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                        maxLines: 9999,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 38,
                      width: 29,
                      top: 697,
                      height: 26,
                      child: Image.asset('images/image12_281396.png', width: 29, height: 26,),
                    ),
                    Positioned(
                      left: 38,
                      width: 29,
                      top: 744,
                      height: 26,
                      child: Image.asset('images/image13_281397.png', width: 29, height: 26,),
                    ),
                    Positioned(
                      left: 115,
                      width: 128,
                      top: 179,
                      height: 24,
                      child: Container(
                        width: 128,
                        height: 24,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 4360,
              width: 430,
              top: 0,
              height: 932,
              child: Container(
                width: 430,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 110,
                      width: 332,
                      top: -196,
                      height: 330,
                      child: Image.asset('images/image1_244672.png', width: 332, height: 330,),
                    ),
                    Positioned(
                      left: -210,
                      width: 487,
                      top: -166,
                      height: 432,
                      child: Image.asset('images/image2_244666.png', width: 487, height: 432,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 50,
                      child: Container(
                        width: 430,
                        height: 50,
                        decoration: BoxDecoration(
                          color: const Color(0xffffffff),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 0, top: 21, right: 0, bottom: 0),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        mainAxisSize: MainAxisSize.max,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 16, top: 0, right: 6, bottom: 0),
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.center,
                                                  mainAxisSize: MainAxisSize.max,
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Text(
                                                      '9:41',
                                                      textAlign: TextAlign.center,
                                                      style: TextStyle(decoration: TextDecoration.none, fontSize: 17, color: const Color(0xff000000), fontFamily: 'SFPro-Semibold', fontWeight: FontWeight.normal),
                                                      maxLines: 9999,
                                                      overflow: TextOverflow.ellipsis,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                          const SizedBox(width: 134),
                                          const SizedBox(width: 134),
                                          Expanded(
                                            child: Container(
                                              width: double.infinity,
                                              child: Padding(
                                                padding: const EdgeInsets.only(left: 6, top: 0, right: 16, bottom: 0),
                                                child: Image.asset('images/image_I24461012871948.png',),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 898,
                      height: 34,
                      child: Image.asset('images/image3_244611.png', width: 430, height: 34,),
                    ),
                    Positioned(
                      left: 315.32,
                      width: 5.26,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image4_244612.png', width: 5.26, height: 2.027,),
                    ),
                    Positioned(
                      left: 303.05,
                      width: 29.8,
                      top: 76.578,
                      height: 25.924,
                      child: Image.asset('images/image5_244613.png', width: 29.8, height: 25.924,),
                    ),
                    Positioned(
                      left: 300,
                      width: 36,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image6_244614.png', width: 36, height: 32,),
                    ),
                    Positioned(
                      left: 47,
                      width: 40,
                      top: 855,
                      height: 34.476,
                      child: Image.asset('images/image7_244615.png', width: 40, height: 34.476,),
                    ),
                    Positioned(
                      left: 194,
                      width: 35,
                      top: 859,
                      height: 33,
                      child: Image.asset('images/image8_244618.png', width: 35, height: 33,),
                    ),
                    Positioned(
                      left: 336,
                      width: 38,
                      top: 855,
                      height: 39,
                      child: Image.asset('images/image9_244619.png', width: 38, height: 39,),
                    ),
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 837,
                      height: 1,
                      child: Container(
                        width: 430,
                        height: 1,
                        decoration: BoxDecoration(
                          border: Border.all(color: const Color(0xffcacaca), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 571,
                      width: 76,
                      top: 613.5,
                      height: 25,
                      child: Image.asset('images/image10_244623.png', width: 76, height: 25,),
                    ),
                    Positioned(
                      left: 39,
                      width: 140,
                      top: 141,
                      height: 21,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 0,
                            top: 0,
                            child: Text(
                              'Donate',
                              textAlign: TextAlign.center,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 40, color: const Color(0xff6e0b2a), fontFamily: 'KaiseiOpti-Bold', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: 360,
                      width: 28,
                      top: 79,
                      height: 22.5,
                      child: Image.asset('images/image11_244651.png', width: 28, height: 22.5,),
                    ),
                    Positioned(
                      left: 41,
                      width: 352,
                      top: 595,
                      height: 39,
                      child: Container(
                        width: 352,
                        height: 39,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              left: 0,
                              width: 352,
                              top: 0,
                              height: 39,
                              child: Container(
                                width: 352,
                                height: 39,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Stack(
                                  children: [
                                    Positioned(
                                      left: 0,
                                      width: 352,
                                      top: 0,
                                      height: 39,
                                      child: Container(
                                        width: 352,
                                        height: 39,
                                        decoration: BoxDecoration(
                                          color: const Color(0xff6e0b2a),
                                          border: Border.all(color: const Color(0xff802642), width: 1),
                                          borderRadius: BorderRadius.circular(10),
                                          boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      left: 94,
                                      width: 165,
                                      top: 8,
                                      height: 26,
                                      child: Text(
                                        'Submit',
                                        textAlign: TextAlign.center,
                                        style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xffffffff), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                        maxLines: 9999,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      left: 39,
                      width: 354,
                      top: 200,
                      height: 374,
                      child: Stack(
                        children: [
                          Positioned(
                            left: 2,
                            width: 107,
                            top: 0,
                            child: Text(
                              'Full name',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 0,
                            width: 352,
                            top: 28,
                            height: 49,
                            child: Container(
                              width: 352,
                              height: 49,
                              decoration: BoxDecoration(
                                color: const Color(0xffffffff),
                                border: Border.all(color: const Color(0xff802642), width: 1),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 26,
                            top: 36,
                            child: Text(
                              'Aminah Hamid',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 2,
                            width: 134,
                            top: 89,
                            child: Text(
                              'Phone number',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 2,
                            width: 155,
                            top: 293,
                            child: Text(
                              'Donation tracking',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 2,
                            width: 352,
                            top: 121,
                            height: 49,
                            child: Container(
                              width: 352,
                              height: 49,
                              decoration: BoxDecoration(
                                color: const Color(0xffffffff),
                                border: Border.all(color: const Color(0xff802642), width: 1),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 2,
                            width: 352,
                            top: 325,
                            height: 49,
                            child: Container(
                              width: 352,
                              height: 49,
                              decoration: BoxDecoration(
                                color: const Color(0xffffffff),
                                border: Border.all(color: const Color(0xff802642), width: 1),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 26,
                            width: 207,
                            top: 129,
                            child: Text(
                              '012-49888746',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff111719), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 26,
                            width: 207,
                            top: 333,
                            child: Text(
                              'Link to tracking',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xffcacaca), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 2,
                            width: 155,
                            top: 191,
                            child: Text(
                              'Donation date',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          Positioned(
                            left: 2,
                            width: 352,
                            top: 223,
                            height: 49,
                            child: Container(
                              width: 352,
                              height: 49,
                              decoration: BoxDecoration(
                                color: const Color(0xffffffff),
                                border: Border.all(color: const Color(0xff802642), width: 1),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: const [BoxShadow(color: const Color(0x3fe8e8e8), offset: Offset(15, 20), blurRadius: 45),],
                              ),
                            ),
                          ),
                          Positioned(
                            left: 27,
                            width: 20,
                            top: 237,
                            height: 20,
                            child: Image.asset('images/image_281426.png', width: 20, height: 20,),
                          ),
                          Positioned(
                            left: 62,
                            width: 207,
                            top: 234,
                            child: Text(
                              'Choose date',
                              textAlign: TextAlign.left,
                              style: TextStyle(decoration: TextDecoration.none, fontSize: 16, color: const Color(0xffcacaca), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                              maxLines: 9999,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              left: 2383,
              width: 315,
              top: 0,
              height: 932,
              child: Container(
                width: 315,
                height: 932,
                decoration: BoxDecoration(
                  color: const Color(0xffffffff),
                  border: Border.all(color: const Color(0xff000000), width: 1),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      width: 430,
                      top: 0,
                      height: 252,
                      child: Container(
                        width: 430,
                        height: 252,
                        decoration: BoxDecoration(
                          color: const Color(0x68ffbbbb),
                          border: Border.all(color: const Color(0xd2ffcc99), width: 1),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 230.99,
                      width: 3.853,
                      top: 103.444,
                      height: 2.027,
                      child: Image.asset('images/image1_268355.png', width: 3.853, height: 2.027,),
                    ),
                    Positioned(
                      left: 219.767,
                      width: 26.372,
                      top: 75,
                      height: 32,
                      child: Image.asset('images/image2_268360.png', width: 26.372, height: 32,),
                    ),
                    Positioned(
                      left: 79.618,
                      width: 159,
                      top: 123.5,
                      height: 159,
                      child: Image.asset('images/image3_268432.png', width: 159, height: 159,),
                    ),
                    Positioned(
                      left: 91,
                      width: 140,
                      top: 428,
                      height: 38,
                      child: Container(
                        width: 140,
                        height: 38,
                        decoration: BoxDecoration(
                          color: const Color(0x7fffffff),
                          border: Border.all(color: const Color(0xff802642), width: 1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.only(left: 8, top: 16, right: 8, bottom: 16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Image.asset('images/image_309387.png', width: 23, height: 22,),
                              const SizedBox(width: 24),
                              Text(
                                'Logout',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 20, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      left: 81,
                      width: 158,
                      top: 141,
                      height: 124,
                      child: Image.asset('images/image4_268462.png', width: 158, height: 124, fit: BoxFit.contain,),
                    ),
                    Positioned(
                      left: 78,
                      top: 318,
                      child: Text(
                        'Sarah Suhairi',
                        textAlign: TextAlign.center,
                        style: TextStyle(decoration: TextDecoration.none, fontSize: 24, color: const Color(0xff000000), fontFamily: 'Kadwa-Regular', fontWeight: FontWeight.normal),
                        maxLines: 9999,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Positioned(
                      left: 239,
                      width: 45,
                      top: 69,
                      height: 44,
                      child: Image.asset('images/image5_270471.png', width: 45, height: 44, fit: BoxFit.cover,),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
